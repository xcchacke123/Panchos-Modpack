EUFONIA — Texture Pack para Minecraft 1.21

Incluye:
- Logo de la pantalla principal reemplazado por "EUFONIA".
- Estética de interfaz limpia y minimalista.
- Pack icon personalizado.
- Compatible con Minecraft Java 1.21 / 1.21.1 (pack_format 34).

Instalación:
1. Abre Minecraft Java.
2. Opciones → Paquetes de recursos.
3. Abre la carpeta del pack.
4. Copia el archivo ZIP allí y selecciónalo dentro de Minecraft.

Nota:
La UI completa de Minecraft está repartida en muchas texturas. Esta primera versión
cambia el branding principal sin tocar texturas de bloques, ítems ni fuentes.
