EUFONIA — UI EDITION — Minecraft Java 1.21

Diseño:
• Menús y HUD en azul noche / cristal oscuro.
• Bordes suaves y acentos celestes.
• Logo EUFONIA en lugar del branding de Minecraft.
• Hotbar, selección, botones, HUD, inventario y creativo rediseñados.
• Interfaz pensada para mantener buena legibilidad y aspecto limpio.

Instalación:
1. Minecraft Java 1.21 → Opciones → Paquetes de recursos.
2. Abrir carpeta del paquete.
3. Copiar EUFONIA_UI_1.21.zip.
4. Activarlo y colocarlo por encima del pack predeterminado.

Nota:
Algunas pantallas del menú principal de Java usan elementos que no son una sola textura.
Este pack prioriza las texturas de GUI/HUD que sí puede reemplazar un resource pack vanilla.
